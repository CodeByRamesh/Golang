package main

import (
	"time"
	"net/http"
	"html/template"
	"path/filepath"
	"example.com/codebunk/internal/models"
)

// _________________________________________________________________
// _________________________________________________________________

type templateData struct {
	CurrentYear int
	Code *models.Code
	Codes []*models.Code
	// More Memeber You Can Add...
}

// _________________________________________________________________

// Adding Custom Template Functions
// There are two main steps to doing this:
// 		1. We need to create a template.FuncMap object containing 
//			the custom humanDate() function.
// 		2. We need to use the template.Funcs() method to register 
//			this before parsing the templates.

func humanDate( t time.Time ) string {
	return t.Format(" 02 Jan 2006 at 15:04")
}

// Initialize a template.FuncMap object and store it in a 
// global variable. This is essentially a string-keyed map 
// which acts as a lookup between the names of our
// custom template functions and the functions themselves.
var templateCustomFunctions = template.FuncMap{
	// Custome TAG : Custom Function
	"humanDate" : humanDate,
}

// _________________________________________________________________

func (app *application ) newTemplateData( r *http.Request ) *templateData {
	return &templateData {
		CurrentYear: time.Now().Year(),
	}
}

// _________________________________________________________________

func newTemplateCache() (map[string]*template.Template, error) {
    // Initialize a new map to act as the cache.
	cache := map[string]*template.Template{}

    // Use the filepath.Glob() function to get a slice of all filepaths that
    // match the pattern "./ui/html/pages/*.tmpl". This will essentially gives
    // us a slice of all the filepaths for our application 'page' templates
    // like: [ui/html/pages/home.tmpl ui/html/pages/view.tmpl]
	pages, err := filepath.Glob("./ui/html/pages/*.tmpl")
	if err != nil {
		return nil, err
	}

    // Loop through the page filepaths one-by-one.
	for _, page := range pages {
        // Extract the file name (like 'home.tmpl') from the full filepath
        // and assign it to the name variable.		
		name := filepath.Base( page )

        // Create a slice containing the filepaths for our base template, any
        // partials and the page.

        // Parse the base template file into a template set.
		baseTemplate := "./ui/html/base.tmpl"
		// template, err := template.ParseFiles( baseTemplate )
		
		// Customised Template With Custom Functions And Tags
		customeTemplate := template.New(name).Funcs(templateCustomFunctions)
		template, err := customeTemplate.ParseFiles( baseTemplate )
		if err != nil {
			return nil, err
		}
		
		// files := []string {
		// 	"./ui/html/partials/nav.tmpl",
		// 	page,
		// }

        // Parse the files into a template set.
        partialTemplates := "./ui/html/partials/*.tmpl"
		template, err = template.ParseGlob( partialTemplates )
		if err != nil {
			return nil, err
		}

		// template, err = template.ParseFiles( page )
		template, err = customeTemplate.ParseFiles( page )
		if err != nil {
			return nil, err
		}

        // Add the template set to the map, using the name of the page
        // (like 'home.tmpl') as the key.
		cache[ name ] = template
	}

    // Return the Cache map.
	return cache, nil
}



// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________


