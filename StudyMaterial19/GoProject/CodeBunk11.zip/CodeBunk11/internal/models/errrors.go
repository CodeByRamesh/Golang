package models

import (
	"errors"
)

var ErrNoRecord = errors.New("Models: No Matching Record Found")

