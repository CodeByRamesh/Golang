package main

import (
	"net/http"
)

func (app *application) routes() *http.ServeMux {
	mux := http.NewServeMux()

	fileServer := http.FileServer( http.Dir("./ui/static/") )
	mux.Handle( "/static/", http.StripPrefix("/static", fileServer) )

	// Adding Routes With Path And Action
	// 		Path Is "/" 			and Action Is home
	// 		Path Is "/code/view" 	and Action Is codeView
	// 		Path Is "/code/create" 	and Action Is codeCreate
	mux.HandleFunc( "/", app.home )
	mux.HandleFunc( "/code/view", 	app.codeView )
	mux.HandleFunc( "/code/create", app.codeCreate )

	return mux
}
