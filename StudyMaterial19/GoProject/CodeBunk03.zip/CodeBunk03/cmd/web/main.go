package main

import (
	"fmt"
	"net/http"
	"os"
	"flag"
	"log"
)

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

// Logger Design 03 : Application Wide Configuration Management Design
// Configuring Application Wide Configurations
type application struct {
	// Adding Logging Configuration
	infoLog 	* log.Logger
	errorLog 	* log.Logger
}

// _________________________________________________________________
// _________________________________________________________________

func main() {
	//1. Get Configuration
	// go run ./cmd/web/ -address=":8000"
	address := flag.String("address", ":4000", "HTTP Network Address")
	flag.Parse()

	//2. Configure Application
	// Logger Design 03 Using Application 
	app := &application {
		infoLog  : log.New( os.Stdout, "INFO\t", log.Ldate|log.Ltime ),
		errorLog : log.New( os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile ),
	}

	// Logger Design 03
	app.infoLog.Println("Starting Server On Port: ", *address)

	//3. Configure HTTP Server
	server := &http.Server {
		Addr: *address,
		ErrorLog: errorLog,
		Handler: app.routes(),
	}
	
	//4. Start HTTP Server
	err := server.ListenAndServe() // Registering Multiplexer

	// Logger Design 03
	app.infoLog.Println("Starting Server On Port: ", *address)
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

