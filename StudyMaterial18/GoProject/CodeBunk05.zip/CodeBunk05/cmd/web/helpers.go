package main

import (
	"fmt"
	"net/http"
	"runtime/debug"
)

func (app *application) serverError( w http.ResponseWriter, err error ) {
	// In the serverError() helper we use the debug.Stack() function to 
	// get a stack trace for the current goroutine and append it to the 
	// log message. Being able to see the execution path of the application 
	// via the stack trace can be helpful when you’re trying to debug errors.

	trace := fmt.Sprintf("%s\n%s", err.Error(), debug.Stack() )
	// app.errorLog.Println( trace )
	app.errorLog.Output(2, trace )

	http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
}

func (app *application) clientError( w http.ResponseWriter, status int ) {
	// In the clientError() helper we use the http.StatusText() function 
	// to automatically generate a human-friendly text representation of 
	// a given HTTP status code. For example, http.StatusText(400) will 
	// return the string "Bad Request".

	http.Error(w, http.StatusText( status ), http.StatusInternalServerError)
}

func (app *application) notFound( w http.ResponseWriter) {
	app.clientError(w, http.StatusNotFound)
}

